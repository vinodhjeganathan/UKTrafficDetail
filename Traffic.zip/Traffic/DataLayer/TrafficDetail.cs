namespace DataLayer
{
    /// <summary>
    /// Entity class for traffic detail
    /// </summary>
    public partial class TrafficDetail
    {
        public int Id { get; set; }
        public int Year { get; set; }
        public int RouteInfoId { get; set; }
        public int PedalCycles { get; set; }
        public int MotorCycles { get; set; }
        public int CarsTaxis { get; set; }
        public int BusesCoaches { get; set; }
        public int LightGoodsVehicles { get; set; }
        public int V2AxleRigidHGV { get; set; }
        public int V3AxleRigidHGV { get; set; }
        public int V4or5AxleRigidHGV { get; set; }
        public int V3or4AxleArticHGV { get; set; }
        public int V5AxleArticHGV { get; set; }
        public int V6orMoreAxleArticHGV { get; set; }
        public virtual RouteInfo RouteInfo { get; set; }
    }
}
