﻿namespace DataLayer.Interface.IRepository
{
    /// <summary>
    /// Interface for <see cref="TrafficDetail"/> repository
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface ITrafficDetailRepository : ICreateAsync<TrafficDetail>, IUpdateAsync<TrafficDetail>, IGetAync<TrafficDetail>, IGetAsyncById<TrafficDetail>, IDeleteAsync
    {
        //Created a repository pattern for traffic detail entity
        //Created interface in datalayer to avoid the circular reference if in interface class
    }
}
