﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Threading.Tasks;

using DataLayer.Interface.IRepository;

namespace DataLayer
{
    /// <summary>
    /// Repository class for <see cref="TrafficDetail"/>
    /// </summary>
    public class TrafficDetailRepository : RepositoryBase, ITrafficDetailRepository
    {
        /// <summary>
        /// Constructor for <see cref="TrafficDetailRepository"/>
        /// </summary>
        /// <param name="context">The entity framework context</param>
        public TrafficDetailRepository(TrafficRouteDatabaseEntities context) : base(context)
        {
        }

        /// <summary>
        /// The create entity method for traffic details
        /// </summary>
        /// <param name="entity">The entity</param>
        /// <returns>The entity</returns>
        public async Task<TrafficDetail> CreateAsync(TrafficDetail entity)
        {
            _context.TrafficDetails.Add(entity);
            await _context.SaveChangesAsync();
            return entity;
        }

        /// <summary>
        /// The delete method for traffic details
        /// </summary>
        /// <param name="id">The primary key of the traffic detail</param>
        public async Task DeleteAsync(int id)
        {
            var trafficDetail = new TrafficDetail() { Id = id };
            _context.TrafficDetails.Attach(trafficDetail);
            _context.TrafficDetails.Remove(trafficDetail);
            await _context.SaveChangesAsync();
        }

        /// <summary>
        /// The get method for traffic details
        /// </summary>
        /// <returns>The list of traffic details</returns>
        public async Task<IEnumerable<TrafficDetail>> GetAsync()
        {
            return await _context.TrafficDetails.ToListAsync();
        }

        /// <summary>
        /// The get by id method for traffic detail
        /// </summary>
        /// <param name="id">The primary key</param>
        /// <returns>The entity object</returns>
        public async Task<TrafficDetail> GetByIdAsync(int id)
        {
            return await _context.TrafficDetails.FirstOrDefaultAsync(x => x.Id == id);
        }

        /// <summary>
        /// Updates the traffic details
        /// </summary>
        /// <param name="entity">The entity object</param>
        /// <returns>The updated object</returns>
        public async Task<TrafficDetail> UpdateAsync(TrafficDetail entity)
        {
            var trafficDetail = await GetByIdAsync(entity.Id);
            trafficDetail.PedalCycles = entity.PedalCycles;
            trafficDetail.MotorCycles = entity.MotorCycles;
            await _context.SaveChangesAsync();
            return entity;
        }
    }
}
