﻿namespace Common.Enum
{
    /// <summary>
    /// Enum class for junctions
    /// </summary>
    public enum Junction
    {
        Other = 1,
        Sidmouth = 252,
        StationRd = 253,
        StokeHill = 254,
        SummerLane = 255,
        TamertonRdRoundabout = 256,
        TelegraphHill = 258,
        WestawayPlain = 260,
        WhiddonDrive = 261
    }
}
