﻿namespace Common.Enum
{
    /// <summary>
    /// Enum class for road category
    /// </summary>
    public enum RoadCategory
    {
        PA = 1,
        TA = 2,
        TM = 2
    }
}
