﻿namespace Common.Enum
{
    /// <summary>
    /// Enum class for local authority
    /// </summary>
    public enum LocalAuthority
    {
        Devon = 1
    }
}
