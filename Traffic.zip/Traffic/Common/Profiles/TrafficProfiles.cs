﻿using AutoMapper;

using DataLayer;
using Dto = Common.DataTransferObject;

namespace Common.Profiles
{
    /// <summary>
    /// Profile class for traffic
    /// </summary>
    public class TrafficProfiles : Profile
    {
        public TrafficProfiles()
        {
            CreateMap<Dto.TrafficDetail, TrafficDetail>();

            CreateMap<TrafficDetail, Dto.TrafficDetail>();
        }
    }
}
