﻿namespace Common.DataTransferObject
{
    /// <summary>
    /// Base class for dto id
    /// </summary>
    public abstract class DtoBase
    {
        public int Id { get; set; }
    }
}
