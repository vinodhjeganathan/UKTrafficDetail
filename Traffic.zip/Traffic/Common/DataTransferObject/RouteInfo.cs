﻿using Common.Enum;

namespace Common.DataTransferObject
{
    /// <summary>
    /// Route information dto
    /// </summary>
    public class RouteInfo : DtoBase
    {
        public int CP { get; set; }
        public Junction StartJunction { get; set; }
        public Junction EndJunction { get; set; }
        public RoadCategory RoadCategory { get; set; }
        public Region Region { get; set; }
        public LocalAuthority LocalAuthority { get; set; }
        public decimal Kms { get; set; }
        public decimal Miles { get; set; }
    }
}