using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using Business.Interface;
using Microsoft.AspNetCore.Mvc;
using Dto = Common.DataTransferObject;

namespace Api.Controllers
{
    /// <summary>
    /// Api Controller for traffic details
    /// </summary>
    [Route("api/[controller]")]
    public class TrafficController : ApiController
    {
        private readonly IService<Dto.TrafficDetail> _service;

        /// <summary>
        /// Controller for <see cref="TrafficController"/>
        /// </summary>
        /// <param name="service">The traffic detail service</param>
        public TrafficController(IService<Dto.TrafficDetail> service)
        {
            _service = service;
        }

        /// <summary>
        /// Gets all the traffic details
        /// </summary>
        /// <returns>The collection of traffic details</returns>
        [HttpGet]
        public async Task<HttpResponseMessage> GetAllAsync()
        {
            var c = await _service.GetAsync();
            return Request.CreateResponse(HttpStatusCode.OK, c);
        }

        /// <summary>
        /// Gets the traffic details by id
        /// </summary>
        /// <param name="id">The key for the traffic detail</param>
        /// <returns>The traffic detail object</returns>
        [HttpGet("{id}")]
        public async Task<HttpResponseMessage> GetTodoItem(int id)
        {
            //Guard class can be implemented in places like this if we need to record the exception
            //https://deviq.com/guard-clause/
            var todoItem = await _service.GetByIdAsync(id);

            if (todoItem == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            return Request.CreateResponse(HttpStatusCode.OK, todoItem);
        }

        /// <summary>
        /// Creates the traffic detail record
        /// </summary>
        /// <param name="requestDto">The request object</param>
        /// <returns>The created object</returns>
        [HttpPost]
        public async Task<HttpResponseMessage> CreateAsync(Dto.TrafficDetail requestDto)
        {
            return Request.CreateResponse(HttpStatusCode.Created, await _service.CreateAsync(requestDto));
        }

        /// <summary>
        /// Updates the traffic detail record
        /// </summary>
        /// <param name="requestDto">The request object</param>
        /// <returns>The updated object</returns>
        [HttpPut]
        public async Task<HttpResponseMessage> UpdateAsync(Dto.TrafficDetail requestDto)
        {
            return Request.CreateResponse(HttpStatusCode.Accepted, await _service.UpdateAsync(requestDto));
        }

        /// <summary>
        /// End point for deleting the traffic detail
        /// </summary>
        /// <param name="id">The key for the traffic detail</param>
        [HttpDelete("{id}")]
        public async Task<HttpResponseMessage> DeleteAsync(int id)
        {
            await _service.DeleteAsync(id);
            return Request.CreateResponse(HttpStatusCode.NoContent);
        }
    }
}
