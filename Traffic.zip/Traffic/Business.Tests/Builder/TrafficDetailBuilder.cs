﻿using DataLayer;

namespace Web.Api.Tests.Builder
{
    /// <summary>
    /// Builder class for <see cref="TrafficDetail"/>
    /// </summary>
    public class TrafficDetailBuilder
    {
        #region Private members

        private int _year;

        private int _routeInfoId;

        private int _pedalCycles;

        private int _motorCycles;

        private int _carsTaxis;

        private int _busesCoaches;

        private int _lightGoodsVehicles;

        private int _v2AxleRigidHGV;

        private int _v3AxleRigidHGV;

        private int _v4or5AxleRigidHGV;

        private int _v3or4AxleArticHGV;

        private int _v5AxleArticHGV;

        private int _v6orMoreAxleArticHGV;

        #endregion

        /// <summary>
        /// Constructor for <see cref="TrafficDetailBuilder"/>
        /// </summary>
        public TrafficDetailBuilder()
        {
            _year = 2001;
            _routeInfoId = 1;
            _pedalCycles = 100;
            _motorCycles = 101;
            _carsTaxis = 102;
            _busesCoaches = 103;
            _lightGoodsVehicles = 104;
            _v2AxleRigidHGV = 105;
            _v3AxleRigidHGV = 106;
            _v4or5AxleRigidHGV = 107;
            _v3or4AxleArticHGV = 108;
            _v5AxleArticHGV = 109;
            _v6orMoreAxleArticHGV = 110;
        }

        /// <summary>
        /// Build method for<see cref="TrafficDetailBuilder"/>
        /// </summary>
        /// <returns>The traffic detail object</returns>
        public TrafficDetail Build()
        {
            return new TrafficDetail()
            {
                Year = _year,
                RouteInfoId = _routeInfoId,
                PedalCycles = _pedalCycles,
                MotorCycles = _motorCycles,
                CarsTaxis = _carsTaxis,
                BusesCoaches = _busesCoaches,
                LightGoodsVehicles = _lightGoodsVehicles,
                V2AxleRigidHGV = _v2AxleRigidHGV,
                V3AxleRigidHGV = _v3AxleRigidHGV,
                V4or5AxleRigidHGV = _v4or5AxleRigidHGV,
                V5AxleArticHGV = _v5AxleArticHGV,
                V6orMoreAxleArticHGV = _v6orMoreAxleArticHGV
            };
        }
    }
}
