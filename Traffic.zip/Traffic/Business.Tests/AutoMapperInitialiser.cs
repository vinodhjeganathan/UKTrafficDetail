﻿using AutoMapper;

using Common.Profiles;

namespace Web.Api.Tests
{
    /// <summary>
    /// Auto mapper initialized
    /// </summary>
    public static class AutoMapperInitialiser
    {
        private static object _thisLock = new object();
        private static bool _initialized = false;

        /// <summary>
        /// Create mapper method
        /// </summary>
        /// <returns>Initialized auto mapper</returns>
        public static IMapper CreateMapper()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<TrafficProfiles>();
            });

            return config.CreateMapper();
        }
    }
}
