﻿using System.Threading.Tasks;

using Moq;
using Xunit;

using Business;
using Business.Services;
using DataLayer;
using DataLayer.Interface.IRepository;
using Web.Api.Tests.Builder;

namespace Web.Api.Tests.Tests
{
    /// <summary>
    /// Test class for <see cref="TrafficService"/>
    /// </summary>
    public class TrafficServiceTest
    {
        private TrafficService _trafficService;
        private Mock<ITrafficDetailRepository> _mockRepository;
        private TrafficDetail _trafficDetail;

        public TrafficServiceTest()
        {
            _trafficDetail = new TrafficDetailBuilder().Build();
            _mockRepository = new Mock<ITrafficDetailRepository>();

            _mockRepository.Setup(x => x.GetByIdAsync(It.IsAny<int>())).Returns(Task.FromResult(_trafficDetail));
            _trafficService = new TrafficService(_mockRepository.Object, AutoMapperInitialiser.CreateMapper());
        }

        [Fact]
        [Trait("Service Tests", "TrafficService")]
        public async Task ServiceClass_Inherits_ServiceBase()
        {
            // Assert
            Assert.IsAssignableFrom<ServiceBase>(_trafficService);
        }

        [Fact]
        [Trait("Service Tests", "TrafficService")]
        public async Task GetByIdAsync_Calls_GetByIdAsyncDatalayer()
        {
            // Act
            var result = await _trafficService.GetByIdAsync(default(int));

            // Assert
            _mockRepository.Verify(x => x.GetByIdAsync(default(int)), Times.Once);
        }
    }
}
