﻿using System.Threading.Tasks;

namespace DataLayer.Interface
{
    /// <summary>
    /// Interface for creating the record
    /// </summary>
    /// <typeparam name="T">The entity type</typeparam>
    public interface ICreateAsync<T>
    {
        /// <summary>
        /// Create method for recording the new data
        /// </summary>
        /// <param name="entity">The entity</param>
        /// <returns>The key of the created object</returns>
        Task<T> CreateAsync(T entity);
    }
}