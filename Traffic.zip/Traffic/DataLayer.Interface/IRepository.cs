﻿namespace DataLayer.Interface
{
    /// <summary>
    /// Interface for service layer with all CRUD operations
    /// </summary>
    /// <typeparam name="T">The object</typeparam>
    public interface IRepository<T> : ICreateAsync<T>, IUpdateAsync<T>, IGetAync<T>, IGetAsyncById<T>, IDeleteAsync
    {
        //Created separate interface for each interface as per Interface segregration principle
    }
}