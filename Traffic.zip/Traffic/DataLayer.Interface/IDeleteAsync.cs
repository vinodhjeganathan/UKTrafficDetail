﻿using System.Threading.Tasks;

namespace DataLayer.Interface
{
    /// <summary>
    /// Interface for deleting the record
    /// </summary>
    public interface IDeleteAsync
    {
        /// <summary>
        /// Delete method for removing the data
        /// </summary>
        /// <param name="id">The primary key of the record</param>
        Task DeleteAsync(int id);
    }
}