﻿using System.Threading.Tasks;

namespace DataLayer.Interface
{
    /// <summary>
    /// Interface for updating the record
    /// </summary>
    public interface IUpdateAsync<T>
    {
        /// <summary>
        /// Update method for updating the data
        /// </summary>
        /// <param name="entity">The entity</param>
        /// <returns>Returns the updated object</returns>
        Task<T> UpdateAsync(T entity);
    }
}