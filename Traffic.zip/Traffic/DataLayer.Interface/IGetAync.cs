﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace DataLayer.Interface
{
    /// <summary>
    /// Interface for get async
    /// </summary>
    /// <typeparam name="T">The entity type</typeparam>
    public interface IGetAync<T>
    {
        /// <summary>
        /// Get method for retrieving all the data
        /// </summary>
        /// <returns>The list of T</returns>
        Task<IEnumerable<T>> GetAsync();
    }
}
