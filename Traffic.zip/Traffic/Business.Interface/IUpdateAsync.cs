﻿using System.Threading.Tasks;

namespace Business.Interface
{
    /// <summary>
    /// Interface for updating the record
    /// </summary>
    public interface IUpdateAsync<T>
    {
        /// <summary>
        /// Update method for updating the data
        /// </summary>
        /// <param name="dataTransferObject">The data transfer object</param>
        /// <returns>Returns the updated object</returns>
        Task<T> UpdateAsync(T dataTransferObject);
    }
}