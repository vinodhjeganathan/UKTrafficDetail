﻿namespace Business.Interface
{
    /// <summary>
    /// Interface for service layer with all CRUD operations
    /// </summary>
    /// <typeparam name="T">The object</typeparam>
    public interface IService<T> : ICreateAsync<T>, IUpdateAsync<T>, IGetAync<T>, IGetAsyncById<T>, IDeleteAsync
    {
        //Created separate interface for each interface as per Interface segregration principle
    }
}