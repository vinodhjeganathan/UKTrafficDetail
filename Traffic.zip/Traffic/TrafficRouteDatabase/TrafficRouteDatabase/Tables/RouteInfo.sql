﻿CREATE TABLE [dbo].[RouteInfo]
(
	[Id] INT NOT NULL IDENTITY(1,1),
	[CP] INT NOT NULL,
	[StartJunctionId] INT NOT NULL,
	[EndJunctionId] INT NOT NULL,
	[RoadCategoryId] INT NOT NULL,
	[RegionId] INT NOT NULL,
	[LocalAuthorityId] INT NOT NULL,
	[Kms] DECIMAL(6,2) NOT NULL,
	[Miles] DECIMAL(6,2) NOT NULL
	CONSTRAINT PK_RouteInfo PRIMARY KEY ([Id]),
	CONSTRAINT FK_RouteInfoHasStartJunctions FOREIGN KEY ([StartJunctionId]) REFERENCES [Junctions]([Id]),
	CONSTRAINT FK_RouteInfoHasEndJunctions FOREIGN KEY ([EndJunctionId]) REFERENCES [Junctions]([Id]),
	CONSTRAINT FK_RouteInfoHasRoadCategory FOREIGN KEY ([RoadCategoryId]) REFERENCES [RoadCategory]([Id]),
	CONSTRAINT FK_RouteInfoHasRegion FOREIGN KEY ([RegionId]) REFERENCES [Region]([Id]),
	CONSTRAINT FK_RouteInfoHasLocalAuthority FOREIGN KEY ([LocalAuthorityId]) REFERENCES [LocalAuthority]([Id])
);
--CONSTRAINT UK_RouteInfoCP UNIQUE ([CP]),(Removed this unqiue key from the table 
--as data has some duplicates in terms of junction names like rd for road
--which created duplicate issue with the constraint