﻿CREATE TABLE [dbo].[EstimationMethod]
(
	[Id] INT NOT NULL,
	[EstimationMethod] NVARCHAR(50) NOT NULL,
	CONSTRAINT PK_EstimationMethod PRIMARY KEY ([Id])
);