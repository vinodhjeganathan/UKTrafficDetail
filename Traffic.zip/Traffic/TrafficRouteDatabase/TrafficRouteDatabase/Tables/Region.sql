﻿CREATE TABLE [dbo].[Region]
(
	[Id] INT NOT NULL,
	[Region] NVARCHAR(50) NOT NULL,
	CONSTRAINT PK_Region PRIMARY KEY ([Id])
);