﻿CREATE TABLE [dbo].[LocalAuthority]
(
	[Id] INT NOT NULL,
	[LocalAuthority] NVARCHAR(50) NOT NULL,
	CONSTRAINT PK_LocalAuthority PRIMARY KEY ([Id])
);