﻿CREATE TABLE [dbo].[TrafficDetail]
(
	[Id] INT NOT NULL IDENTITY(1,1),
	[Year] INT NOT NULL,
	[RouteInfoId] INT NOT NULL,
	[PedalCycles] INT NOT NULL,
	[MotorCycles] INT NOT NULL,
	[CarsTaxis] INT NOT NULL,
	[BusesCoaches] INT NOT NULL,
	[LightGoodsVehicles] INT NOT NULL,
	[V2AxleRigidHGV] INT NOT NULL,
	[V3AxleRigidHGV] INT NOT NULL,
	[V4or5AxleRigidHGV] INT NOT NULL,
	[V3or4AxleArticHGV] INT NOT NULL,
	[V5AxleArticHGV] INT NOT NULL,
	[V6orMoreAxleArticHGV] INT NOT NULL
	CONSTRAINT PK_TrafficDetail PRIMARY KEY ([Id]),
	CONSTRAINT FK_TrafficDetailHasRouteInfo FOREIGN KEY (RouteInfoId) REFERENCES [RouteInfo]([Id])
);