﻿CREATE TABLE [dbo].[Junctions]
(
	[Id] INT NOT NULL,
	[Junctions] NVARCHAR(100) NOT NULL,
	CONSTRAINT PK_Junctions PRIMARY KEY ([Id])
);