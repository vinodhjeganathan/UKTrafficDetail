﻿MERGE INTO 
	[dbo].[Region] AS Target
USING 
(
	VALUES
	(1,'South West')
) AS Source ([Id], [Region])
ON (Target.[Id] = Source.[Id])
WHEN 
	MATCHED AND (Target.[Region] <> Source.[Region]) THEN
		UPDATE SET [Region] = Source.[Region]
WHEN
	NOT MATCHED BY TARGET THEN
		INSERT([Id], [Region])
			VALUES(Source.[Id], Source.[Region])
WHEN 
	NOT MATCHED BY SOURCE THEN
		DELETE;