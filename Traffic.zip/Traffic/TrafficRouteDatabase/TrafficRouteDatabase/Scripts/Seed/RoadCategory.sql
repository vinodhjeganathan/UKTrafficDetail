﻿MERGE INTO 
	[dbo].[RoadCategory] AS Target
USING 
(
	VALUES
	(1,'PA'),
	(2,'TA'),
	(3,'TM')
) AS Source ([Id], [RoadCategory])
ON (Target.[Id] = Source.[Id])
WHEN 
	MATCHED AND (Target.[RoadCategory] <> Source.[RoadCategory]) THEN
		UPDATE SET [RoadCategory] = Source.[RoadCategory]
WHEN
	NOT MATCHED BY TARGET THEN
		INSERT([Id], [RoadCategory])
			VALUES(Source.[Id], Source.[RoadCategory])
WHEN 
	NOT MATCHED BY SOURCE THEN
		DELETE;