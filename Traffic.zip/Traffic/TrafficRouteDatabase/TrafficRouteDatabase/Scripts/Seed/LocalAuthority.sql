﻿MERGE INTO 
	[dbo].[LocalAuthority] AS Target
USING 
(
	VALUES
	(1,'Devon')
) AS Source ([Id], [LocalAuthority])
ON (Target.[Id] = Source.[Id])
WHEN 
	MATCHED AND (Target.[LocalAuthority] <> Source.[LocalAuthority]) THEN
		UPDATE SET [LocalAuthority] = Source.[LocalAuthority]
WHEN
	NOT MATCHED BY TARGET THEN
		INSERT([Id], [LocalAuthority])
			VALUES(Source.[Id], Source.[LocalAuthority])
WHEN 
	NOT MATCHED BY SOURCE THEN
		DELETE;