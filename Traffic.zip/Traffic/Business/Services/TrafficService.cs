﻿using System.Collections.Generic;
using System.Threading.Tasks;

using AutoMapper;

using Business.Interface;
using DataLayer;
using DataLayer.Interface.IRepository;
using Dto = Common.DataTransferObject;

namespace Business.Services
{
    /// <summary>
    /// Service class for traffic details
    /// </summary>
    public class TrafficService : ServiceBase, IService<Dto.TrafficDetail>
    {
        private readonly ITrafficDetailRepository _repository;

        /// <summary>
        /// Constructor for <see cref="TrafficService"/>
        /// </summary>
        /// <param name="repository">The traffic detail repository</param>
        public TrafficService(ITrafficDetailRepository repository, IMapper mapper) : base(mapper)
        {
            _repository = repository;
        }

        /// <summary>
        /// Create traffic detail record
        /// </summary>
        /// <param name="dataTransferObject">The traffic detail dto</param>
        /// <returns>The created record</returns>
        public async Task<Dto.TrafficDetail> CreateAsync(Dto.TrafficDetail dataTransferObject)
        {
            return Mapper.Map<Dto.TrafficDetail>(await _repository.CreateAsync(Mapper.Map<TrafficDetail>(dataTransferObject)));
        }

        /// <summary>
        /// Deletes the traffic detail by id
        /// </summary>
        /// <param name="id">The primary key of the traffic detail</param>
        public async Task DeleteAsync(int id)
        {
            await _repository.DeleteAsync(id);
        }

        /// <summary>
        /// Gets all traffic details
        /// </summary>
        /// <returns>Collection of traffic details</returns>
        public async Task<IEnumerable<Dto.TrafficDetail>> GetAsync()
        {
            return Mapper.Map<Dto.TrafficDetail[]>(await _repository.GetAsync());
        }

        /// <summary>
        /// Gets the traffic detail by id
        /// </summary>
        /// <param name="id">The traffic detail key</param>
        /// <returns>The traffic detail object</returns>
        public async Task<Dto.TrafficDetail> GetByIdAsync(int id)
        {
            return Mapper.Map<Dto.TrafficDetail>(await _repository.GetByIdAsync(id));
        }

        /// <summary>
        /// Updates the traffic detail
        /// </summary>
        /// <param name="dataTransferObject">The traffic detail object</param>
        /// <returns>The updated object</returns>
        public async Task<Dto.TrafficDetail> UpdateAsync(Dto.TrafficDetail dataTransferObject)
        {
            return Mapper.Map<Dto.TrafficDetail>(await _repository.UpdateAsync(Mapper.Map<TrafficDetail>(dataTransferObject)));
        }
    }
}