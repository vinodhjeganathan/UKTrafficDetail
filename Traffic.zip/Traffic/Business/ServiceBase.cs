﻿using AutoMapper;

namespace Business
{
    /// <summary>
    /// Base class for services
    /// </summary>
    public abstract class ServiceBase
    {
        protected readonly IMapper Mapper;

        /// <summary>
        /// Constructor for <see cref="ServiceBase"/>
        /// </summary>
        /// <param name="mapper">The mapper instance</param>
        public ServiceBase(IMapper mapper)
        {
            Mapper = mapper;
        }
    }
}